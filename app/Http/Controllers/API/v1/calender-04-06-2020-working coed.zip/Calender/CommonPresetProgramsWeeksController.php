<?php

namespace App\Http\Controllers\API\v1\Calender;

use App\Supports\DateConvertor;
use App\Http\Controllers\Controller;

class CommonPresetProgramsWeeksController extends Controller
{
    use DateConvertor;
}
